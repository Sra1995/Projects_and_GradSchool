// Algorithm Steps for Solving the 8-Puzzle using a Parallel Approach

#include <iostream>
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <mpi.h>
#include <chrono>
#include <algorithm>

using namespace std;

const int N = 3; // Define the 8-puzzle grid size

// Function to calculate the Manhattan Distance
int manhattanDistance(const vector<vector<int>>& state, const vector<vector<int>>& goal) {
    int distance = 0;
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            if (state[i][j] != 0) {
                for (int x = 0; x < N; ++x) {
                    for (int y = 0; y < N; ++y) {
                        if (state[i][j] == goal[x][y]) {
                            distance += abs(i - x) + abs(j - y);
                        }
                    }
                }
            }
        }
    }
    return distance;
}

// Function to print the puzzle state
void printState(const vector<vector<int>>& state) {
    for (const auto& row : state) {
        for (int tile : row) {
            cout << tile << " ";
        }
        cout << endl;
    }
}

// Function to check if the current state is the goal state
bool isGoalState(const vector<vector<int>>& state, const vector<vector<int>>& goal) {
    return state == goal;
}

// Function to generate possible moves from the current state
vector<vector<vector<int>>> generateMoves(const vector<vector<int>>& state, int blankRow, int blankCol) {
    vector<vector<vector<int>>> moves;
    vector<pair<int, int>> directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
    for (const auto& dir : directions) {
        int newRow = blankRow + dir.first;
        int newCol = blankCol + dir.second;
        if (newRow >= 0 && newRow < N && newCol >= 0 && newCol < N) {
            vector<vector<int>> newState = state;
            swap(newState[blankRow][blankCol], newState[newRow][newCol]);
            moves.push_back(newState);
        }
    }
    return moves;
}

// Function to find the position of the empty tile (represented by 0)
pair<int, int> findEmptyTile(const vector<vector<int>>& state) {
    for (int i = 0; i < state.size(); ++i) {
        for (int j = 0; j < state[i].size(); ++j) {
            if (state[i][j] == 0) {
                return {i, j};
            }
        }
    }
    return {-1, -1}; // Return -1, -1 if no empty tile is found
}

int main(int argc, char* argv[]) {
    MPI_Init(&argc, &argv); // Initialize the MPI environment

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank); // Get the rank of the process
    MPI_Comm_size(MPI_COMM_WORLD, &size); // Get the number of processes

    // Define the start and goal states of the puzzle
    vector<vector<int>> startState = {{1, 2, 3}, {4, 0, 5}, {6, 7, 8}};
    vector<vector<int>> goalState = {{1, 2, 3}, {4, 5, 6}, {7, 8, 0}};

    // Priority queue to store the states to be explored, ordered by their Manhattan distance
    priority_queue<pair<int, vector<vector<int>>>, vector<pair<int, vector<vector<int>>>>, greater<pair<int, vector<vector<int>>>>> pq;
    set<vector<vector<int>>> visited; // Set to keep track of visited states

    if (rank == 0) {
        // Push the start state into the priority queue with its Manhattan distance
        pq.push({manhattanDistance(startState, goalState), startState});
        visited.insert(startState); // Mark the start state as visited
    }

    bool goalFound = false; // Flag to indicate if the goal state has been found
    vector<vector<int>> goalStateFound; // Variable to store the found goal state

    while (true) {
        if (rank == 0) {
            // If the goal state is found or the priority queue is empty, break the loop
            if (goalFound || pq.empty()) {
                break;
            }

            int taskCount = min((int)pq.size(), size - 1);
            vector<vector<vector<int>>> tasks(taskCount);

            for (int i = 0; i < taskCount; ++i) {
                tasks[i] = pq.top().second;
                pq.pop();
            }

            for (int i = 1; i <= taskCount; ++i) {
                MPI_Send(tasks[i - 1].data(), N * N, MPI_INT, i, 0, MPI_COMM_WORLD);
            }
        }

        vector<int> receivedState(N * N);

        if (rank > 0) {
            MPI_Status status;
            MPI_Recv(receivedState.data(), N * N, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);

            vector<vector<int>> state(N, vector<int>(N));
            for (int i = 0; i < N; ++i) {
                for (int j = 0; j < N; ++j) {
                    state[i][j] = receivedState[i * N + j];
                }
            }

            if (isGoalState(state, goalState)) {
                goalFound = true;
                goalStateFound = state;
            }

            pair<int, int> blankPos = findEmptyTile(state);
            auto moves = generateMoves(state, blankPos.first, blankPos.second);

            for (const auto& move : moves) {
                if (visited.find(move) == visited.end()) {
                    visited.insert(move);
                    MPI_Send(move.data(), N * N, MPI_INT, 0, 1, MPI_COMM_WORLD);
                }
            }

            MPI_Send(nullptr, 0, MPI_INT, 0, 2, MPI_COMM_WORLD);
        }

        if (rank == 0) {
            for (int i = 1; i < size; ++i) {
                MPI_Status status;
                MPI_Recv(receivedState.data(), N * N, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);

                if (status.MPI_TAG == 1) {
                    vector<vector<int>> state(N, vector<int>(N));
                    for (int i = 0; i < N; ++i) {
                        for (int j = 0; j < N; ++j) {
                            state[i][j] = receivedState[i * N + j];
                        }
                    }

                    int distance = manhattanDistance(state, goalState);
                    pq.push({distance, state});

                    if (isGoalState(state, goalState)) {
                        goalFound = true;
                        goalStateFound = state;
                    }
                }
            }
        }

        MPI_Bcast(&goalFound, 1, MPI_C_BOOL, 0, MPI_COMM_WORLD);
        if (goalFound) {
            break;
        }
    }

    if (rank == 0 && goalFound) {
        cout << "Goal state found:" << endl;
        printState(goalStateFound);
    }

    MPI_Finalize(); // Finalize the MPI environment
    return 0;
}
