package step1;

public class Threaded extends Thread {
    public void run() {
        System.out.println("Threaded Thread: Say hi once.");
    }
}
